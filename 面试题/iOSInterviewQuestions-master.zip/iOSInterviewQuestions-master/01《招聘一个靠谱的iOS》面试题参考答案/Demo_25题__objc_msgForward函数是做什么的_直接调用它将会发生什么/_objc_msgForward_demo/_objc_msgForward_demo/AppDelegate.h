//
//  AppDelegate.h
//  _objc_msgForward_demo
//
//  Created by http://weibo.com/luohanchenyilong/ (微博@iOS程序犭袁)on 15/9/10.
//  Copyright (c) 2015年 https://github.com/ChenYilong . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

